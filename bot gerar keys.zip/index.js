console.clear()
const Discord = require("discord.js");
const { GatewayIntentBits } = require('discord.js');
const { ActivityType } = require("discord.js");

// DB
const { QuickDB } = require("quick.db");
global.db = new QuickDB();
//

const config = require("./config.json");

const client = new Discord.Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        '32767'
    ]
});

global.embed_color = config.client.embed;

module.exports = client

client.on('interactionCreate', (interaction) => {

    if (interaction.type === Discord.InteractionType.ApplicationCommand) {

        const cmd = client.slashCommands.get(interaction.commandName);

        if (!cmd) return interaction.reply({ content: `Erro, este comando não existe`, ephemeral: true });

        interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);

        cmd.run(client, interaction)

    }
});


client.on("ready", async () => {
console.log(`[BOT] O ${client.user.username} está online.`)
    console.log(`[SERVIDORES] Estou em ${client.guilds.cache.size} servidores.`)
    console.log(`[INFORMAÇÕES] Bot pra fazer key.`)
    client.user.setActivity({
		name: "PaivaX#5271", /////tira os credito bot n funciona
		type: "PLAYING"
    })
});
    console.log(`

${"             ██████╗░░█████╗░██╗██╗░░░██╗░█████╗░██╗░░██╗"}
${"             ██╔══██╗██╔══██╗██║██║░░░██║██╔══██╗╚██╗██╔╝"}
${"             ██████╔╝███████║██║╚██╗░██╔╝███████║░╚███╔╝░"} 
${"             ██╔═══╝░██╔══██║██║░╚████╔╝░██╔══██║░██╔██╗░"}
${"             ██║░░░░░██║░░██║██║░░╚██╔╝░░██║░░██║██╔╝╚██╗"}
${"             ╚═╝░░░░░╚═╝░░╚═╝╚═╝░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝"}


`)

/*============================= | Import handler | =========================================*/

client.slashCommands = new Discord.Collection()

require('./handler')(client)

client.login(config.client.token)

/*============================= | Anti OFF | =========================================*/

// process.on('multipleResolves', (type, reason, promise) => {
//     return;
// });
// process.on('unhandRejection', (reason, promise) => {
//     return;
// });
// process.on('uncaughtException', (error, origin) => {
//     return;
// });
// process.on('uncaughtException', (error, origin) => {
//     return;
// });